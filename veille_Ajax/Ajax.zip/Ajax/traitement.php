<?php
require_once 'base.php';

//On verifie les donnees de reception
$nom=$_POST['nom'];
$email=$_POST['email'];
$comment=$_POST['comment'];

$requette=bd()->prepare ('INSERT INTO personne(nom, email, comment) value(?,?,?)');
$requette->execute (array($nom,$email,$comment));
echo "donnees sauvegardee";
?>