
var nom=document.getElementById("nom");
var prenom=document.getElementById("email");
var age=document.getElementById("comment");
var submit=document.getElementById("submit");

var reponse=document.getElementById("reponse");

submit.addEventListener("click",function() {
    var requete=new XMLHttpRequest();
    requete.open('POST','traitement.php');
    requete.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    requete.send('nom='+nom.value+'&email='+prenom.value+'&comment='+age.value);
    
    requete.onreadystatechange=function versPhp(data) {
        if(requete.readyState==4 && requete.status==200){
            reponse.textContent=requete.responseText;
        }
    }
});
