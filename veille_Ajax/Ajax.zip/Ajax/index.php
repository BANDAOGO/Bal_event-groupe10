
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.min.css">
    <title>test</title>
</head>

<body style="background-image: url('overlay.png');">
   <p style="text-align: center; margin-top: 20p; font-size: 30px; font-family: cambria">Presenter par:</p>  
   <p style="text-align: center; margin-top: 20p; font-size: 30px; font-family: cambria; color: blue">JUSTIN ET OUSSENI</p>
   <div class="container" style="margin-top: 2em; background-color: rgb(222, 235, 242); border-radius: 10px; padding-bottom: 20px; padding: 30px">
     <label for=""> Entrer votre nom: </label>
     <input class="form-control" type="text" id="nom"> <br>
     <label for=""> Entrer votre email: </label>
     <input class="form-control" type="text" id="email"><br>
     <label for=""> Laisser votre commentaire: </label>
     <textarea class="form-control" id="comment" rows="5"></textarea><br>
     <button class="btn btn-success pull-right btn" id="submit">Envoyer</button>

     <h5 style="color:red;" id="reponse">aucune donne sauvegarder pour le moment</h5>
   </div>
   <script src="script.js"></script>
</body>
</html>